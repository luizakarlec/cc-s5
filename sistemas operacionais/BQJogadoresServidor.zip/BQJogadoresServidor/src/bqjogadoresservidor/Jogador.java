package bqjogadoresservidor;

import static java.lang.Math.random;
import static java.lang.StrictMath.random;

public class Jogador implements Runnable {
    private Buffer buffer;
    private int id;
    private String nickname;

    public Jogador(Buffer buffer, int id, String nickname) {
        this.buffer = buffer;
        this.id = id;
        this.nickname = nickname;
    }
    
    @Override
    public void run(){
        try {
            long intervalo = (long) (Math.random() * 2000) + 500; // entre 500ms e 2500ms
            Thread.sleep(intervalo);
            buffer.inserirJogadores(this);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}
