package bqjogadoresservidor;

public class Principal {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        
        // múltiplas threads de jogadores
        String[] nicks = {"NightWolf", "IronMage", "ShadowX", "DragonFire", "PrettyRainbow", "John67"};
        int[] ids = {123, 456, 789, 101, 873, 074};

        for (int i = 0; i < nicks.length; i++) {
            Thread jogador = new Thread(new Jogador(buffer, ids[i], nicks[i]));
            jogador.start();
        }

        //uma thread de servidor
        Thread servidor = new Thread(new Servidor(buffer));
        servidor.start();
    }
}
