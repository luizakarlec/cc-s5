package bqjogadoresservidor;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class Buffer {
    private BlockingQueue<Jogador> fila = new ArrayBlockingQueue<>(5);
    
    public void inserirJogadores(Jogador j) throws InterruptedException{
            fila.put(j);
            System.out.println("Jogador " + j.getNickname() + " entrou na fila");
    }
    
    public void consumir() throws InterruptedException{
        Jogador j1 = fila.take();
        Jogador j2 = fila.take();
        System.out.println("\nPartida iniciada: " + j1.getNickname() + " VS " + j2.getNickname() + "\n");
    }
}
