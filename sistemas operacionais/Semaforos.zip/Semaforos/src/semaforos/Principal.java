package semaforos;

public class Principal {
    public static void main(String[] args) {
        Buffer bufferCompartilhado = new Buffer();
        Thread threadProdutor = new Thread(new Produtor(bufferCompartilhado));
        Thread threadConsumidor = new Thread(new Consumidor(bufferCompartilhado));
        
        threadProdutor.start();
        threadConsumidor.start();
    }
}
