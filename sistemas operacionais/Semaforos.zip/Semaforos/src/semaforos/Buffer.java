package semaforos;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

public class Buffer {
    private Queue<Integer> queue = new LinkedList<>();
    private static final int CAPACITY = 5;
    private Semaphore semFull = new Semaphore(0);
    private Semaphore semEmpty = new Semaphore(CAPACITY);
    
    public void put(int item) throws InterruptedException {
        semEmpty.acquire(); // Adquire um espaço vazio
        synchronized (this) {
            queue.add(item);
            System.out.println("Produzindo: " + item);
        }
        semFull.release(); // Libera um espaço cheio
    }
    
    public int get() throws InterruptedException {
        semFull.acquire(); // Adquire um espaço cheio
        int item;
        synchronized (this) {
            item = queue.poll();
            System.out.println("Consumindo: " + item);
        }
        semEmpty.release(); // Libera um espaço vazio
        return item;
    }
}
