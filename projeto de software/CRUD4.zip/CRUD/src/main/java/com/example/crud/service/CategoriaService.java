package com.example.crud.service;

import com.example.crud.model.Categoria;
import com.example.crud.model.Produto;
import com.example.crud.repository.CategoriaRepository;
import com.example.crud.repository.ProdutoRepository;
import org.springframework.stereotype.Service;

@Service
public class CategoriaService {
    private final CategoriaRepository categoriaRepository;

    public CategoriaService(CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public void salvar(Categoria categoria) {
        if(categoria.getNome() == null || categoria.getNome().isBlank()) {
            throw new RuntimeException("O nome do produto é obrigatório.");
        }
        categoriaRepository.save(categoria);
    }
}
